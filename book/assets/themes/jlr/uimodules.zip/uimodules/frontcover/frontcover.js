define(["text!./frontcover.html", "require", "knockout", "jquery", "WebUtility", "jqueryTouchSwipe", "less!./frontcover"],
function(htmlTemplate, require, ko, $, WebUtility, swipe) {

    function viewModel(params) {
        var self = this;

        self.id = params.id;
        self.settings = params.settings;
        var toolbox = params.settings.toolbox;
        var options = params.config.options;
        var elem = $(params.elem);
        var mBook = params.mBook;

        self.instruction = WebUtility.IsMobile() ? self.settings.mobileInstruction() : self.settings.desktopInstruction();
        //self.logoVisible = ko.observable(false);
        self.logoCss = ko.observable(self.settings.logoPosition());
        self.titleVisible = ko.observable(false);
        self.subtitleVisible = ko.observable(false);
        //self.instructionVisible = ko.observable(false);

        function animateLogos() {
            setTimeout(function() {
                //self.logoVisible(true);
                self.logoCss(self.logoCss() + " show");
            }, 300);
            setTimeout(function() {
                self.titleVisible(true);
            }, 600);
            setTimeout(function() {
                self.subtitleVisible(true);
            }, 1200);
            /*
            setTimeout(function() {
                self.instructionVisible(true);
                elem.click(function() {
                    elem.fadeOut(500);
                });
            }, 2000);
            */
            setTimeout(function() {
                //$('#results').css('display','block').fadeIn(1000);
                $('#results').show("slow");
                //$('#results').css('display','block');
                $('.frontcover .video-container .mesh').css('background-color','black');
                $('.video-container').animate({ opacity: 1/2 }, 1000);
            }, 5000);
        }

    /*
    if (!self.settings.video())
        animateLogos();

    var timer = self.settings.continueTimer ? self.settings.continueTimer() : false;

    if (timer !== false && !isNaN(timer) && timer > 0) {
        setTimeout(function() {
            elem.fadeOut(500);
        }, timer);
    };
    */

    self.logo = ko.computed(function() {
        return self.settings.logo() ? require.toUrl(params.config.assets + self.settings.logo()) : "";
    });

    self.logoWidth = self.settings.logoWidth;
    self.logoMaxWidth = self.settings.logoMaxWidth;

    self.video = self.settings.video() ? 'assets/' + mBook.theme.path + '/assets/vid/' + self.settings.video() : "";

    self.backgroundImage = self.settings.backgroundImage() ? 'url(assets/' + mBook.theme.path + '/assets/img/' + self.settings.backgroundImage() + ')' : "";

    self.videoOverlay = self.settings.videoOverlay() ? 'url(assets/' + mBook.theme.path + '/assets/img/' + self.settings.videoOverlay() + ')' : "";

    self.videoPoster = self.settings.videoPoster() ? 'assets/' + mBook.theme.path + '/assets/img/' + self.settings.videoPoster() : "";

    self.title = self.settings.title() ? self.settings.title() : mBook.GetTitle();

    self.subtitle = self.settings.subtitle();

    //self.hideTitles = self.settings.hideTitles();

    self.showPlayButton = ko.observable(false)

    self.playIcon = ko.observable("");
    self.playButton = ko.observable();

    self.playIcon.subscribe(function(newVal) {
        WebUtility.FileToImageTag(newVal, function(html) {
            self.playButton(html);
        })
    })

    self.playIcon(mBook.theme.path + "/assets/img/" + self.settings.playIcon());


    self.playVideo = null;

    if (WebUtility.isIOS() && WebUtility.IOSVersion() < 10) {
        self.showPlayButton(true);
    }

    ko.bindingHandlers.videoHandlers = {
        init: function(video) {

            video.onplaying = function() {
                self.showPlayButton(false);
                animateLogos();
            }

            self.playVideo = function() {
                video.play();
            }

        }
    }

};

return {
    viewModel: viewModel,
    template: htmlTemplate
};
});
